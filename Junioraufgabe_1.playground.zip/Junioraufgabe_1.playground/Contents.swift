import Foundation


struct Haus {       //Vorlage für die Speicherung der Koordinaten eines Hauses
    var x: Int
    var y: Int
}
struct Windrad {     //Vorlage für die Speicherung der Koordinaten eines Windrads
    var x: Int
    var y: Int
}

let data = """
12 3
-82 -315
248 714
1202 907
226 680
694 -20
-767 44
-245 719
-339 36
473 406
863 -290
953 885
-109 510
1242 -593
-1223 -1479
1720 401
"""

var firstDataArray = data.split(whereSeparator: \.isNewline)
let x = firstDataArray[0].components(separatedBy: " ")
let anzahlHäuser = Int(x[0])!
let anzahlWindräder = Int(x[1])!
let y = Int(x[0])! + Int(x[1])!
var dataArray: [Int] = []
firstDataArray.remove(at: 0)
for i in 0...y-1{
    let first = firstDataArray[0].components(separatedBy: " ")
    firstDataArray.remove(at: 0)
    dataArray.append(Int(first[0])!)
    dataArray.append(Int(first[1])!)
}

var haeuserKoordinaten: [Haus] = []    //Array um Häuserkoordinaten zu speichern
var windraederKoordinaten: [Windrad] = []     //Array um Windradkoordinaten zu speichern

for i in 1...anzahlHäuser {
    haeuserKoordinaten.append(Haus(x: Int(exactly: dataArray[0])!, y: Int(exactly: dataArray[1])!))    //füllt Häuser Array mit entsprechenden Daten
    for x in 0...1{
    dataArray.remove(at: 0)
    }
}
for i in 1...anzahlWindräder{
    windraederKoordinaten.append(Windrad(x: Int(exactly: dataArray[0])!, y: Int(exactly: dataArray[1])!))    //füllt Windräder Array mit entsprechenden Daten
    for x in 0...1{
    dataArray.remove(at: 0)
    }
}

var hoeheWindraeder: [Double] = []   //Array um später maximale Höhe der einzelnen Windräder zu speichern
var kleinsterAbstand: Double         //Variable zur Speicherung des kleinsten Abstandes zu einem Haus

for i in 1...anzahlWindräder {
    
    let windrad = windraederKoordinaten[i-1]
    kleinsterAbstand = pow(pow(Double(windrad.x - haeuserKoordinaten[0].x), 2) + pow(Double(windrad.y - haeuserKoordinaten[0].y), 2), 0.5)
    //setzt "kleinsterAbstand" auf den Abstand zwischen dem Windrad und dem ersten Haus im Array. Abstand wird über den Satz des Pythagoras berechnet
    
    for i in 1...(anzahlHäuser-1) {
        let Abstand = pow(pow(Double(windrad.x - haeuserKoordinaten[i].x), 2) + pow(Double(windrad.y - haeuserKoordinaten[i-1].y), 2), 0.5)
        if Abstand < kleinsterAbstand {
            kleinsterAbstand = Abstand
        }
        //Berechnet den Abstand zwischen dem Windrad und jedem Haus im Array, falls der Abstand kleiner ist, als der kleinste Abstand zuvor wird er "kleinsterAbstand" gleichgesetzt
    }
    
    hoeheWindraeder.append(kleinsterAbstand/10) //speichert die maximale Höhe des Windrads gemäß der 10H Regel
    
}

for i in 0...(anzahlWindräder-1){
    print("Das Windrad an der Position x=\(windraederKoordinaten[i].x), y=\(windraederKoordinaten[i].y) darf \(String(format: "%.2f", hoeheWindraeder[i])) Meter hoch werden.")
}
//gibt die Maximale Höhe jedes Windrads mit entsprechenden Koordinaten des Windrads aus

