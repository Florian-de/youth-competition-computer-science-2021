import Foundation

let data = """
6 7
0 0 0 0 0 0 0
1 0 0 1 1 0 0
2 2 2 1 2 2 2
2 1 1 1 2 1 2
0 1 2 2 1 0 0
1 2 1 2 0 1 1
"""
var firstDataArray = data.split(whereSeparator: \.isNewline)
let x = firstDataArray[0].components(separatedBy: " ")
firstDataArray.remove(at: 0)
let anzahlMitglieder = Int(x[0])!
let anzahlTermine = Int(x[1])!
var secondDataArray: [[String]] = []
var dataArray: [Int] = []
for i in 1...anzahlMitglieder{
    secondDataArray.append(firstDataArray[0].components(separatedBy: " "))
    firstDataArray.remove(at: 0)
}
let hello = secondDataArray
for i in 0...anzahlMitglieder-1{
    for j in 0...anzahlTermine-1{
        dataArray.append(Int(secondDataArray[i][j])!)
    }
}

var members: [[Int]] = [[]]

for m in 0...(anzahlMitglieder-1){
    var nArray: [Int] = []
    for n in 0...(anzahlTermine-1){
        nArray.append(dataArray[0])
        dataArray.remove(at: 0)
    }
    members.append(nArray)
}
members.remove(at: 0)

let safeArray = members // finaler Array für Nutzung

var m: Int = anzahlTermine // Anzahl Termine
var n: Int = anzahlMitglieder // Anzahl Teilnehmer

var meeting: [Int] = []

for i in 0...(m-1){   //Für jeden Termin,...
    
    meeting.append(0)
    for u in 0...(n-1){    //...wird für jeden Teilnehmer...
        
        let meet0 = safeArray[u][i]
        let countBegin = meeting[i]
        
        for x in 0...(m-1) {       //...bei jedem anderen Termin geschaut...
            
            if countBegin == meeting[i] {   //...wenn noch kein besserer Termin gefunden wurde,...
                
              if safeArray[u][x] < meet0 {      //...ob der Teilnehmer einen besseren Termin angegeben hat
                  meeting[i] += 1
              }
                
            }
            
        }
        
    }
}
for z in 0...(m-1){
    
    var tOf = true
    for x in 0...(m-1){
        if meeting[z] <= meeting[x] {
        }else {
            if z != x{
            tOf = false
            }
        }
        
        }
    if tOf == true {
        print("Das beste Meeting ist \(z+1), es müssen \(meeting[z]) Einträge geändert werden.")
    }
    }


